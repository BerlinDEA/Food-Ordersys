#Instruction in English

# Food-Ordering-System
Food Ordering System is a web application that manages the restaurant menu order between waiter and chef.

## Login Details
For admin:
"admin"
"password"

For staff:
check database




### Notes
1. This is not ready for production.
2. All staff created have same default password : abc123

#Anweistung in Deutsch

# Speisen-Bestell-System
Food Ordering System ist eine Webanwendung, die die Menübestellung im Restaurant zwischen Kellner und Koch verwaltet.


## Login-Daten
Für Administratoren:
"admin"
"password"

Für Personal:
Datenbank prüfen


### Anmerkungen
1. Dies ist nicht produktionsbereit.
2. Alle erstellten Mitarbeiter haben dasselbe Standardpasswort: abc123